import { Page } from '@playwright/test';

export class BasePage {
  constructor(protected readonly page: Page) {}

  async navigateTo(url: string): Promise<void> {
    await this.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
  }

  async waitForPageUrlContains(value: string): Promise<void> {
    await this.page.waitForURL((url) => url.toString().includes(value));
  }
}
