import { expect } from '@playwright/test';
import { BasePage } from './BasePage';

export class HomePage extends BasePage {
  private readonly simpleFormLink = this.page.getByRole('link', { name: 'Simple Form Demo' });

  async openSeleniumPlayground(): Promise<void> {
    await this.navigateTo('https://www.testmuai.com/selenium-playground/');
    await expect(this.page).toHaveTitle(/Selenium/);
  }

  async clickSimpleFormDemo(): Promise<void> {
    await this.simpleFormLink.click();
    await this.waitForPageUrlContains('simple-form-demo');
  }
}
