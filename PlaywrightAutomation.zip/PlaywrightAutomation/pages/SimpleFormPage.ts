import { expect, type Page } from '@playwright/test';
import { BasePage } from './BasePage';

export class SimpleFormPage extends BasePage {
  private readonly messageInput = this.page.getByPlaceholder('Please enter your Message');
  private readonly getCheckedValueButton = this.page.getByRole('button', { name: 'Get Checked Value' });
  private readonly messageLabel = this.page.getByText('Your Message:');

  constructor(page: Page) {
    super(page);
  }

  async open(): Promise<void> {
    await this.navigateTo('https://www.testmuai.com/selenium-playground/simple-form-demo/');
    await expect(this.page.getByRole('heading', { name: 'Simple Form Demo' })).toBeVisible();
  }

  async enterMessage(message: string): Promise<void> {
    await this.messageInput.fill(message);
    await expect(this.messageInput).toHaveValue(message);
  }

  async clickGetCheckedValue(): Promise<void> {
    await this.getCheckedValueButton.click();
  }

  async validateMessageDisplay(expectedMessage: string): Promise<void> {
    await expect(this.messageLabel).toBeVisible();
    await expect(this.page.getByText(expectedMessage, { exact: true })).toBeVisible();
  }
}
