import { expect, type Page } from '@playwright/test';
import { BasePage } from './BasePage';

export class SliderPage extends BasePage {
  private readonly sliderLink = this.page.locator('a[href*="drag-drop-range-sliders-demo"]');
  private readonly slider = this.page.locator('#slider3 input[type="range"]');
  private readonly sliderValue = this.page.locator('#slider3 output');

  constructor(page: Page) {
    super(page);
  }

  async openDragDropSlidersPage(): Promise<void> {
    await this.navigateTo('https://www.testmuai.com/selenium-playground/');
    await this.sliderLink.click();
    await this.waitForPageUrlContains('drag-drop-range-sliders-demo');
  }

  async dragSliderToValue(targetValue: number): Promise<void> {
    const box = await this.slider.boundingBox();
    if (!box) {
      throw new Error('The target slider is not visible on the page.');
    }

    const targetX = box.x + box.width * 0.93;
    await this.page.mouse.move(box.x + 10, box.y + box.height / 2);
    await this.page.mouse.down();
    await this.page.mouse.move(targetX, box.y + box.height / 2, { steps: 20 });
    await this.page.mouse.up();
    await this.page.waitForTimeout(200);

    await expect(this.slider).toHaveValue(String(targetValue));
  }

  async validateValueDisplay(expectedValue: number): Promise<void> {
    await expect(this.sliderValue).toHaveText(String(expectedValue));
  }
}
