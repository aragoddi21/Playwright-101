const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/drag-drop-range-sliders-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  const slider = page.locator('#slider3 input[type="range"]');
  const value = page.locator('#slider3 output');
  const box = await slider.boundingBox();

  for (const frac of [0.80, 0.82, 0.84, 0.85, 0.86, 0.87, 0.88, 0.89, 0.90, 0.91, 0.92, 0.93, 0.94, 0.95]) {
    await slider.evaluate((node) => {
      node.value = 15;
      node.dispatchEvent(new Event('input', { bubbles: true }));
      node.dispatchEvent(new Event('change', { bubbles: true }));
    });
    const targetX = box.x + box.width * frac;
    await page.mouse.move(box.x + 10, box.y + box.height / 2);
    await page.mouse.down();
    await page.mouse.move(targetX, box.y + box.height / 2, { steps: 20 });
    await page.mouse.up();
    await page.waitForTimeout(80);
    console.log('frac', frac, '=>', await slider.inputValue(), 'display', await value.textContent());
  }

  await browser.close();
})();
