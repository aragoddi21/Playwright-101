const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/input-form-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  const fields = await page.locator('form input, form select, form textarea, form button').evaluateAll((els) =>
    els.map((el) => ({
      tag: el.tagName,
      type: el.type || '',
      name: el.name || '',
      placeholder: el.placeholder || '',
      text: el.textContent || '',
      value: el.value || '',
    }))
  );

  console.log(JSON.stringify(fields, null, 2));
  await browser.close();
})();
