const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/input-form-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  const form = page.locator('form:has(input[name="name"])');
  const submit = form.locator('button:has-text("Submit")');
  await submit.click();

  const text = await page.locator('body').innerText();
  console.log('---- page text start ----');
  console.log(text.slice(0, 2500));
  console.log('---- page text end ----');

  const html = await page.locator('body').evaluate((node) => node.innerHTML);
  console.log('contains Please fill in the fields?', html.includes('Please fill in the fields'));
  console.log('contains Thanks for contacting us?', html.includes('Thanks for contacting us'));

  await browser.close();
})();
