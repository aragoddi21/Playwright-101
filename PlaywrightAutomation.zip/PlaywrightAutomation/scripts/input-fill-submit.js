const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/input-form-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  const form = page.locator('form:has(input[name="name"])');
  await form.locator('input[name="name"]').fill('Chetan A');
  await form.locator('input[name="email"]').fill('testmail123@gmail.com');
  await form.locator('input[name="password"]').fill('Test@123');
  await form.locator('input[name="company"]').fill('Testmu AI');
  await form.locator('input[name="website"]').fill('https://www.testmuai.com');
  await form.locator('select[name="country"]').selectOption({ label: 'United States' });
  await form.locator('textarea[name="message"]').fill('Random message for validation');
  await form.locator('button:has-text("Submit")').click();
  await page.waitForTimeout(1200);

  const text = await page.locator('body').innerText();
  console.log('contains Please fill in the fields?', text.includes('Please fill in the fields'));
  console.log('contains Thanks for contacting us?', text.includes('Thanks for contacting us'));
  console.log('body snippet around success text:');
  const idx = text.indexOf('Thanks for contacting us');
  if (idx >= 0) console.log(text.slice(Math.max(0, idx - 200), idx + 400));
  else console.log(text.slice(0, 1800));

  await browser.close();
})();
