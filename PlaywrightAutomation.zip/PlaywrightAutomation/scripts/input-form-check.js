const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/input-form-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  await page.locator('button[type="submit"]').click();
  const bodyText = await page.locator('body').innerText();
  console.log('validation text includes:', bodyText.includes('Please fill in the fields'));
  console.log('validation snippet:', bodyText.slice(bodyText.indexOf('Please fill in the fields') - 80, bodyText.indexOf('Please fill in the fields') + 180));

  await page.locator('input[name="name"]').fill('Chetan A');
  await page.locator('input[name="email"]').fill('testmail123@gmail.com');
  await page.locator('input[name="password"]').fill('Test@123');
  await page.locator('input[name="company"]').fill('Testmu AI');
  await page.locator('input[name="website"]').fill('https://www.testmuai.com');
  await page.locator('select[name="country"]').selectOption({ label: 'United States' });
  await page.locator('textarea[name="message"]').fill('Random message for validation');
  await page.locator('button[type="submit"]').click();
  await page.waitForTimeout(800);

  const finalText = await page.locator('body').innerText();
  console.log('success includes:', finalText.includes('Thanks for contacting us, we will get back to you shortly.'));
  console.log('final snippet:', finalText.slice(0, 2000));

  await browser.close();
})();
