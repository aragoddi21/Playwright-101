const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/simple-form-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  await page.locator("input[placeholder='Please enter your Message']").fill('Welcome to TestMu AI');
  await page.locator('button:has-text("Get Checked Value")').click();
  await page.waitForTimeout(1500);

  const text = await page.locator('text=Your Message:').locator('xpath=following-sibling::*[1]').textContent();
  console.log('URL:', page.url());
  console.log('Displayed:', text);

  await browser.close();
})();
