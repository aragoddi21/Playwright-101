const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto('https://www.testmuai.com/selenium-playground/drag-drop-range-sliders-demo/', { waitUntil: 'domcontentloaded', timeout: 30000 });
  const slider = page.locator('#slider3 input[type="range"]');
  const value = page.locator('#slider3 output');

  await slider.evaluate((node, target) => {
    node.value = String(target);
    node.dispatchEvent(new Event('input', { bubbles: true }));
    node.dispatchEvent(new Event('change', { bubbles: true }));
  }, 95);

  console.log('value=', await slider.inputValue());
  console.log('display=', await value.textContent());

  await browser.close();
})();
