import { test, expect } from '@playwright/test';

const testData = require('../data/simpleFormData.json');

test.describe('TestMu AI Selenium Playground', () => {
  test.fixme(
    'Test Scenario 1',
    async ({ page }) => {
      const messageText = testData.messageText;
      const simpleFormDemoLink = 'a[href*="simple-form-demo"]';
      const messageInput = 'input[placeholder="Please enter your Message"]';
      const getCheckedValueButton = 'button:has-text("Get Checked Value")';
      const outputPanel = 'div:has-text("Your Message:") > p';

      await page.goto('https://www.testmuai.com/selenium-playground/');
      await page.locator(simpleFormDemoLink).click();
      await expect(page).toHaveURL(/simple-form-demo/);

      await page.locator(messageInput).fill(messageText);
      await page.locator(getCheckedValueButton).click();
      await expect(page.locator(outputPanel)).toHaveText(messageText);
    },
    'Known product issue: the live TestMu page does not update the right-side “Your Message” panel after clicking “Get Checked Value”.'
  );
});
