import { test } from '@playwright/test';
import { SliderPage } from '../pages/SliderPage';

const testData = require('../data/sliderData.json');

test('Test Scenario 2: drag the Default value 15 slider to 95', async ({ page }) => {
  const sliderPage = new SliderPage(page);
  const targetValue = testData.targetValue;

  await sliderPage.openDragDropSlidersPage();
  await sliderPage.dragSliderToValue(targetValue);
  await sliderPage.validateValueDisplay(targetValue);
});
